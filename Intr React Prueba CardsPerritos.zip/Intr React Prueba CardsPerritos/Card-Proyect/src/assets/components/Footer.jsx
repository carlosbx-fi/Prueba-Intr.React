const descripFooter = () => {
    return (
        <h5 className="textFooter" >Todos Recursos Reservados @DarknessTony27</h5>
    )
}

export default descripFooter;
import Card from 'react-bootstrap/Card';
import Boton from './Boton';
import Tags from './Tags'

const MyCard = () => {
    return (
        <div className='content' >
        <Card className='contentCard' style={{ width: "18rem" }}>
        <Card.Img variant="top" src="https://picsum.photos/id/237/200/300"
        />
        <Card.Body>
        <Tags title="Adopta un Perrito" />
        <br />
        <Boton />
        <br />
        <br />
        <Tags body="Las siguientes normas deben ser Respetadas, y Contar con ellas Para que la Adopcion Sea Realizada."  />
        </Card.Body>
        </Card>
        <Card className='contentCard' style={{ width: "18rem" }}>
        <Card.Img variant="top" src="https://picsum.photos/id/237/200/300"
        />
        <Card.Body>
        <Tags title="Adopta un Perrito" />
        <br />
        <Boton />
        <br />
        <br />
        <Tags body="Las siguientes normas deben ser Respetadas, y Contar con ellas Para que la Adopcion Sea Realizada."  />
        </Card.Body>
        </Card>
        <Card className='contentCard' style={{ width: "18rem" }}>
        <Card.Img variant="top" src="https://picsum.photos/id/237/200/300"
        />
        <Card.Body>
        <Tags title="Adopta un Perrito" />
        <br />
        <Boton />
        <br />
        <br />
        <Tags body="Las siguientes normas deben ser Respetadas, y Contar con ellas Para que la Adopcion Sea Realizada."  />
        </Card.Body>
        </Card>
        <Card className='contentCard' style={{ width: "18rem" }}>
        <Card.Img variant="top" src="https://picsum.photos/id/237/200/300"
        />
        <Card.Body>
        <Tags title="Adopta un Perrito" />
        <br />
        <Boton />
        <br />
        <br />
        <Tags body="Las siguientes normas deben ser Respetadas, y Contar con ellas Para que la Adopcion Sea Realizada."  />
        </Card.Body>
        </Card>
        </div>
    );
};

export default MyCard;
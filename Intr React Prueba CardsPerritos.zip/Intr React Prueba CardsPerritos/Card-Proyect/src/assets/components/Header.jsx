const Header = () => {
    const TituloName = "Adopciones de Perritos"
    return (
        <h2 className="Titulo" >{TituloName}</h2>
        
    )
}

export default Header;
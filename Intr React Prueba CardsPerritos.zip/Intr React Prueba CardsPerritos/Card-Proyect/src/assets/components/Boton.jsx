import Button from 'react-bootstrap/Button';

const Boton = () => {
    return (
        <>
        <Button variant="primary">Click Aqui Para Adoptar</Button>
        </>
    );
};

export default Boton;
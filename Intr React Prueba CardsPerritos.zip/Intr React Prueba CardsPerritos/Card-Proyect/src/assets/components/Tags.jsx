import Tags from 'react-bootstrap/Badge';

const Badges = (props) => {
    return (
        <>
        <h3>{props.title}</h3>
        <h5>{props.body}</h5>
        </>
    );
};

export default Badges;